<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<header class="fixed w-full bg-white dark:bg-gray-900 shadow-sm z-50">
    <nav class="container mx-auto px-4 py-4 flex justify-between items-center">
        <a href="index.php" class="text-2xl font-bold">Алгоритм</a>
        <div class="hidden md:flex space-x-8">
            <a href="services.php" class="hover:text-gray-600 dark:hover:text-gray-300 transition-all">Услуги</a>
            <a href="about.php" class="hover:text-gray-600 dark:hover:text-gray-300 transition-all">О нас</a>
            <a href="reviews.php" class="hover:text-gray-600 dark:hover:text-gray-300 transition-all">Отзывы</a>
            <a href="faq.php" class="hover:text-gray-600 dark:hover:text-gray-300 transition-all">FAQ</a>
        </div>
        <div class="flex items-center space-x-4">
            <button id="themeToggle" class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path class="dark:hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                    <path class="hidden dark:block" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>
                </svg>
            </button>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="account.php" class="px-4 py-2 rounded-lg bg-gray-900 dark:bg-white text-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">Личный кабинет</a>
            <?php else: ?>
                <a href="login.php" class="px-4 py-2 rounded-lg bg-gray-900 dark:bg-white text-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">Войти</a>
                <a href="register.php" class="px-4 py-2 rounded-lg border border-gray-900 dark:border-white text-gray-900 dark:text-white hover:bg-gray-900 hover:text-white dark:hover:bg-white dark:hover:text-gray-900 transition-all">Регистрация</a>
            <?php endif; ?>
        </div>
    </nav>
</header> 