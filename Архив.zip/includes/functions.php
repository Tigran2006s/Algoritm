<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit();
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header('Location: /index.php');
        exit();
    }
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function formatPrice($price) {
    return number_format($price, 2, '.', ' ') . ' ₽';
}

function getServiceById($pdo, $id) {
    $stmt = $pdo->prepare('SELECT * FROM services WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getAllServices($pdo) {
    $stmt = $pdo->query('SELECT * FROM services ORDER BY created_at DESC');
    return $stmt->fetchAll();
}

function getUserOrders($pdo, $userId) {
    $stmt = $pdo->prepare('
        SELECT o.*, s.title as service_title 
        FROM orders o 
        JOIN services s ON o.service_id = s.id 
        WHERE o.user_id = ? 
        ORDER BY o.created_at DESC
    ');
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

function getPendingReviews($pdo) {
    $stmt = $pdo->query('
        SELECT r.*, u.email as user_email, s.title as service_title 
        FROM reviews r 
        JOIN users u ON r.user_id = u.id 
        JOIN services s ON r.service_id = s.id 
        WHERE r.status = "pending" 
        ORDER BY r.created_at DESC
    ');
    return $stmt->fetchAll();
}

function getApprovedReviews($pdo) {
    $stmt = $pdo->query('
        SELECT r.*, u.email as user_email, s.title as service_title 
        FROM reviews r 
        JOIN users u ON r.user_id = u.id 
        JOIN services s ON r.service_id = s.id 
        WHERE r.status = "approved" 
        ORDER BY r.created_at DESC
    ');
    return $stmt->fetchAll();
} 