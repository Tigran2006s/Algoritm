-- Create database if not exists
CREATE DATABASE IF NOT EXISTS algoritm_db_777 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE algoritm_db_777;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Services table
CREATE TABLE IF NOT EXISTS services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    brief_description TEXT NOT NULL,
    full_description TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    duration_days INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    service_id INT,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    service_id INT NOT NULL,
    status ENUM('pending', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
    total_price DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- Insert default admin user (password: admin123)
INSERT INTO users (email, password, role) VALUES 
('admin@algoritm.ru', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')
ON DUPLICATE KEY UPDATE 
password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
role = 'admin';

-- Insert sample services
INSERT INTO services (title, brief_description, full_description, price, duration_days) VALUES 
('Бизнес-аудит', 'Комплексный анализ бизнес-процессов вашей компании для выявления возможностей оптимизации и роста.', 'Комплексный анализ бизнес-процессов вашей компании для выявления возможностей оптимизации и роста.\n\nЧто входит в услугу:\n- Анализ текущих бизнес-процессов\n- Выявление узких мест и возможностей оптимизации\n- Оценка эффективности использования ресурсов\n- Рекомендации по улучшению процессов\n\nСрок выполнения: 14 дней', 150000.00, 14),
('Стратегическое планирование', 'Разработка долгосрочной стратегии развития компании', 'Разработка долгосрочной стратегии развития компании с учетом рыночных тенденций и внутренних возможностей.', 200000.00, 21),
('Оптимизация процессов', 'Повышение эффективности бизнес-процессов', 'Повышение эффективности бизнес-процессов через внедрение современных методик и технологий.', 180000.00, 30);