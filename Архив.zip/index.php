<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Получение списка услуг из базы данных
try {
    $stmt = $pdo->query('SELECT * FROM services ORDER BY id ASC LIMIT 3');
    $services = $stmt->fetchAll();
} catch (PDOException $e) {
    $services = [];
}
?>
<!DOCTYPE html>
<html lang="ru" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ООО «Алгоритм» - Консалтинговые услуги</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#1a1a1a',
                        secondary: '#f5f5f5',
                    }
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .transition-all {
                transition-property: all;
                transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
                transition-duration: 300ms;
            }
        }
    </style>
</head>
<body class="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="pt-32 pb-20 px-4">
        <div class="container mx-auto text-center">
            <h1 class="text-5xl md:text-6xl font-bold mb-6">Консалтинг от экспертов</h1>
            <p class="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
                Профессиональные консалтинговые услуги для развития вашего бизнеса. 
                Мы помогаем компаниям достигать новых высот через стратегическое планирование и оптимизацию процессов.
            </p>
            <a href="#services" class="inline-block px-8 py-4 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                Наши услуги
            </a>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-20 bg-gray-50 dark:bg-gray-800">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl font-bold text-center mb-12">Наши услуги</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($services as $service): ?>
                <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 hover:shadow-xl transition-all">
                    <h3 class="text-2xl font-bold mb-4"><?php echo htmlspecialchars($service['title']); ?></h3>
                    <p class="text-gray-600 dark:text-gray-300 mb-4">
                        <?php echo htmlspecialchars($service['brief_description']); ?>
                    </p>
                    <div class="flex justify-between items-center mb-4">
                        <span class="text-xl font-bold">от <?php echo number_format($service['price'], 0, ',', ' '); ?> ₽</span>
                        <span class="text-gray-500"><?php echo htmlspecialchars($service['duration_days']); ?> дней</span>
                    </div>
                    <div class="flex space-x-2">
                        <button class="flex-1 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all" onclick="openServiceModal(<?php echo $service['id']; ?>)">
                            Подробнее
                        </button>
                        <?php if (isLoggedIn()): ?>
                            <a href="order.php?service_id=<?php echo $service['id']; ?>" class="flex-1 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all text-center">
                                Заказать
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="flex-1 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all text-center">
                                Войти для заказа
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php if (empty($services)): ?>
            <p class="text-center text-gray-600 dark:text-gray-400">В данный момент услуги недоступны</p>
            <?php else: ?>
            <div class="text-center mt-8">
                <a href="services.php" class="inline-block px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                    Все услуги
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl font-bold text-center mb-12">О нас</h2>
            <div class="max-w-4xl mx-auto">
                <div class="prose dark:prose-invert mx-auto">
                    <p class="text-lg text-gray-600 dark:text-gray-300 mb-6">
                        ООО "Алгоритм" - это команда профессиональных консультантов с многолетним опытом в различных отраслях бизнеса. 
                        Мы помогаем компаниям достигать новых высот через стратегическое планирование и оптимизацию процессов.
                    </p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
                        <div class="text-center">
                            <div class="text-4xl font-bold text-gray-900 dark:text-white mb-2">10+</div>
                            <div class="text-gray-600 dark:text-gray-400">Лет опыта</div>
                        </div>
                        <div class="text-center">
                            <div class="text-4xl font-bold text-gray-900 dark:text-white mb-2">500+</div>
                            <div class="text-gray-600 dark:text-gray-400">Реализованных проектов</div>
                        </div>
                        <div class="text-center">
                            <div class="text-4xl font-bold text-gray-900 dark:text-white mb-2">98%</div>
                            <div class="text-gray-600 dark:text-gray-400">Довольных клиентов</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <section id="reviews" class="py-20 bg-gray-50 dark:bg-gray-800">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl font-bold text-center mb-12">Отзывы клиентов</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php
                try {
                    $stmt = $pdo->query('SELECT r.*, u.email as user_email FROM reviews r LEFT JOIN users u ON r.user_id = u.id ORDER BY created_at DESC LIMIT 3');
                    $reviews = $stmt->fetchAll();
                    
                    foreach ($reviews as $review) {
                        echo '<div class="bg-white dark:bg-gray-900 rounded-lg p-6 shadow-sm">';
                        echo '<div class="flex items-center mb-4">';
                        echo '<div class="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center text-xl font-bold">' . (isset($review['user_email']) ? htmlspecialchars(mb_substr($review['user_email'], 0, 1)) : 'П') . '</div>';
                        echo '<div class="ml-4">';
                        echo '<h3 class="font-bold">' . (isset($review['user_email']) ? htmlspecialchars($review['user_email']) : 'Пользователь') . '</h3>';
                        echo '<p class="text-sm text-gray-500">' . (isset($review['created_at']) ? date('d.m.Y', strtotime($review['created_at'])) : '') . '</p>';
                        echo '</div>';
                        echo '</div>';
                        echo '<p class="text-gray-600 dark:text-gray-400">' . (isset($review['comment']) ? htmlspecialchars($review['comment']) : '') . '</p>';
                        echo '</div>';
                    }
                } catch (PDOException $e) {
                    echo '<p class="text-red-500 text-center">Не удалось загрузить отзывы</p>';
                }
                ?>
                        </div>
            <div class="text-center mt-8">
                <a href="reviews.php" class="inline-block px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                    Смотреть все отзывы
                </a>
            </div>
        </div>
    </section>

    <!-- FAQ Section (Compact Accordion) -->
    <section id="faq" class="py-20">
        <div class="container mx-auto px-4 max-w-2xl">
            <h2 class="text-4xl font-bold text-center mb-8">Часто задаваемые вопросы</h2>
            <div class="space-y-4">
                <div class="bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <button type="button" class="w-full flex justify-between items-center px-6 py-4 text-lg font-medium focus:outline-none faq-toggle" onclick="toggleFaq(0)">
                        Как проходит аудит бизнес-процессов?
                        <svg id="faq-icon-0" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div id="faq-answer-0" class="px-6 pb-4 hidden text-gray-600 dark:text-gray-400">Мы проводим анализ за 3 этапа: сбор данных, анализ процессов, подготовка рекомендаций. На каждом этапе вы получаете промежуточные результаты и можете вносить корректировки.</div>
                </div>
                <div class="bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <button type="button" class="w-full flex justify-between items-center px-6 py-4 text-lg font-medium focus:outline-none faq-toggle" onclick="toggleFaq(1)">
                        Сколько стоит консультация?
                        <svg id="faq-icon-1" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div id="faq-answer-1" class="px-6 pb-4 hidden text-gray-600 dark:text-gray-400">Стоимость зависит от выбранной услуги. Базовый аудит начинается от 150 000 ₽. Точную стоимость мы рассчитываем индивидуально после анализа ваших потребностей.</div>
                </div>
                <div class="bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <button type="button" class="w-full flex justify-between items-center px-6 py-4 text-lg font-medium focus:outline-none faq-toggle" onclick="toggleFaq(2)">
                        Как долго длится проект?
                        <svg id="faq-icon-2" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div id="faq-answer-2" class="px-6 pb-4 hidden text-gray-600 dark:text-gray-400">Сроки зависят от масштаба проекта и выбранной услуги. В среднем от 14 до 30 дней. Точные сроки обсуждаются на этапе планирования.</div>
                </div>
                <div class="bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <button type="button" class="w-full flex justify-between items-center px-6 py-4 text-lg font-medium focus:outline-none faq-toggle" onclick="toggleFaq(3)">
                        Какие документы нужны для начала работы?
                        <svg id="faq-icon-3" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div id="faq-answer-3" class="px-6 pb-4 hidden text-gray-600 dark:text-gray-400">Для начала работы нам потребуется заполненный бриф и основные документы компании. Полный список документов мы предоставляем после первичной консультации.</div>
                </div>
                <div class="bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <button type="button" class="w-full flex justify-between items-center px-6 py-4 text-lg font-medium focus:outline-none faq-toggle" onclick="toggleFaq(4)">
                        Можно ли получить консультацию онлайн?
                        <svg id="faq-icon-4" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div id="faq-answer-4" class="px-6 pb-4 hidden text-gray-600 dark:text-gray-400">Да, мы проводим консультации как очно, так и онлайн через видеоконференции. Выбор формата зависит от ваших предпочтений и специфики проекта.</div>
                            </div>
                <div class="bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <button type="button" class="w-full flex justify-between items-center px-6 py-4 text-lg font-medium focus:outline-none faq-toggle" onclick="toggleFaq(5)">
                        Какие гарантии вы предоставляете?
                        <svg id="faq-icon-5" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                        </button>
                    <div id="faq-answer-5" class="px-6 pb-4 hidden text-gray-600 dark:text-gray-400">Мы гарантируем конфиденциальность информации и качество предоставляемых услуг. Все условия сотрудничества фиксируются в договоре.</div>
                        </div>
                    </div>
            <div class="text-center mt-8">
                <a href="faq.php" class="inline-block px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                    Все вопросы
                </a>
            </div>
        </div>
    </section>

    <!-- Service Modal (универсальный, динамический) -->
    <div id="serviceModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white dark:bg-gray-900 rounded-lg p-8 max-w-2xl w-full mx-4">
            <div class="flex justify-between items-start mb-6">
                <h3 id="modalTitle" class="text-2xl font-bold"></h3>
                <button onclick="closeServiceModal()" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <div id="modalContent" class="text-gray-600 dark:text-gray-300"></div>
        </div>
    </div>

    <!-- Chat Bot -->
    <div id="chatBot" class="fixed bottom-4 right-4 z-50">
        <button onclick="toggleChat()" class="bg-gray-900 dark:bg-white text-white dark:text-gray-900 p-4 rounded-full shadow-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/>
            </svg>
        </button>
        <div id="chatWindow" class="hidden fixed bottom-20 right-4 w-96 bg-white dark:bg-gray-900 rounded-lg shadow-xl">
            <div class="p-4 border-b border-gray-200 dark:border-gray-700">
                <h3 class="font-bold">Чат-бот</h3>
            </div>
            <div id="chatMessages" class="p-4 h-96 overflow-y-auto"></div>
            <div class="p-4 border-t border-gray-200 dark:border-gray-700">
                <input type="text" id="chatInput" class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800" placeholder="Введите сообщение...">
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script>
        // Theme Toggle (объявлять только один раз!)
        const themeToggle = document.getElementById('themeToggle');
        const html = document.documentElement;
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            html.classList.add('dark');
        } else {
            html.classList.remove('dark');
        }
        themeToggle.addEventListener('click', () => {
            html.classList.toggle('dark');
            localStorage.theme = html.classList.contains('dark') ? 'dark' : 'light';
        });

        // FAQ Accordion
        function toggleFaq(idx) {
            const icon = document.getElementById('faq-icon-' + idx);
            const answer = document.getElementById('faq-answer-' + idx);
            icon.classList.toggle('rotate-180');
            answer.classList.toggle('hidden');
        }

        // Service Modal (универсальный)
        const serviceModal = document.getElementById('serviceModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalContent = document.getElementById('modalContent');
        const services = <?php
            $js_services = [];
            foreach ($services as $service) {
                $js_services[$service['id']] = [
                    'title' => $service['title'],
                    'content' => '<p class="mb-4">'.htmlspecialchars($service['full_description']).'</p>'
                        .'<div class="flex justify-between items-center">'
                        .'<span class="text-2xl font-bold">'.number_format($service['price'], 0, ',', ' ').' ₽</span>'
                        .'<span class="text-gray-500">'.$service['duration_days'].' дней</span>'
                        .'</div>'
                ];
            }
            echo json_encode($js_services, JSON_UNESCAPED_UNICODE);
        ?>;
        function openServiceModal(id) {
            const service = services[id];
            if (!service) return;
            modalTitle.textContent = service.title;
            modalContent.innerHTML = service.content;
            serviceModal.classList.remove('hidden');
            serviceModal.classList.add('flex');
        }
        function closeServiceModal() {
            serviceModal.classList.add('hidden');
            serviceModal.classList.remove('flex');
        }

        // Chat Bot
        const chatWindow = document.getElementById('chatWindow');
        const chatMessages = document.getElementById('chatMessages');
        const chatInput = document.getElementById('chatInput');

        function toggleChat() {
            chatWindow.classList.toggle('hidden');
        }

        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && chatInput.value.trim()) {
                const question = chatInput.value.trim();
                chatMessages.innerHTML += `
                    <div class="mb-4">
                        <p class="text-right text-gray-600 dark:text-gray-400">${question}</p>
                    </div>
                `;
                
                let answer = 'Извините, я не могу ответить на этот вопрос. Пожалуйста, свяжитесь с нашим менеджером.';
                
                for (const [key, value] of Object.entries(faq)) {
                    if (question.toLowerCase().includes(key.toLowerCase())) {
                        answer = value;
                        break;
                    }
                }

                setTimeout(() => {
                    chatMessages.innerHTML += `
                        <div class="mb-4">
                            <p class="text-left text-gray-600 dark:text-gray-400">${answer}</p>
                        </div>
                    `;
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }, 500);

                chatInput.value = '';
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        });

        // Additional Services Toggle
        function toggleAdditionalServices() {
            const additionalServices = document.getElementById('additionalServices');
            const showMoreBtn = document.getElementById('showMoreBtn');
            
            if (additionalServices.classList.contains('hidden')) {
                additionalServices.classList.remove('hidden');
                showMoreBtn.textContent = 'Скрыть';
            } else {
                additionalServices.classList.add('hidden');
                showMoreBtn.textContent = 'Показать еще';
            }
        }
    </script>
</body>
</html> 