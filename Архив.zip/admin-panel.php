<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

requireAdmin();

$success = '';
$error = '';

// Handle service management
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Ошибка безопасности. Пожалуйста, попробуйте снова.';
    } else {
        switch ($_POST['action']) {
            case 'add_service':
                $title = sanitizeInput($_POST['title'] ?? '');
                $brief_description = sanitizeInput($_POST['brief_description'] ?? '');
                $full_description = sanitizeInput($_POST['full_description'] ?? '');
                $price = (float)($_POST['price'] ?? 0);
                $duration_days = (int)($_POST['duration_days'] ?? 0);

                if (empty($title) || empty($brief_description) || empty($full_description) || $price <= 0 || $duration_days <= 0) {
                    $error = 'Пожалуйста, заполните все поля корректно';
                } else {
                    $stmt = $pdo->prepare('INSERT INTO services (title, brief_description, full_description, price, duration_days) VALUES (?, ?, ?, ?, ?)');
                    try {
                        $stmt->execute([$title, $brief_description, $full_description, $price, $duration_days]);
                        $success = 'Услуга успешно добавлена';
                    } catch (PDOException $e) {
                        $error = 'Ошибка при добавлении услуги';
                    }
                }
                break;

            case 'edit_service':
                $id = (int)($_POST['id'] ?? 0);
                $title = sanitizeInput($_POST['title'] ?? '');
                $brief_description = sanitizeInput($_POST['brief_description'] ?? '');
                $full_description = sanitizeInput($_POST['full_description'] ?? '');
                $price = (float)($_POST['price'] ?? 0);
                $duration_days = (int)($_POST['duration_days'] ?? 0);

                if (empty($title) || empty($brief_description) || empty($full_description) || $price <= 0 || $duration_days <= 0) {
                    $error = 'Пожалуйста, заполните все поля корректно';
                } else {
                    $stmt = $pdo->prepare('UPDATE services SET title = ?, brief_description = ?, full_description = ?, price = ?, duration_days = ? WHERE id = ?');
                    try {
                        $stmt->execute([$title, $brief_description, $full_description, $price, $duration_days, $id]);
                        $success = 'Услуга успешно обновлена';
                    } catch (PDOException $e) {
                        $error = 'Ошибка при обновлении услуги';
                    }
                }
                break;

            case 'delete_service':
                $id = (int)($_POST['id'] ?? 0);
                $stmt = $pdo->prepare('DELETE FROM services WHERE id = ?');
                try {
                    $stmt->execute([$id]);
                    $success = 'Услуга успешно удалена';
                } catch (PDOException $e) {
                    $error = 'Ошибка при удалении услуги';
                }
                break;

            case 'moderate_review':
                $id = (int)($_POST['id'] ?? 0);
                $action = $_POST['moderation_action'] ?? '';
                if (in_array($action, ['approve', 'reject'])) {
                    $stmt = $pdo->prepare('UPDATE reviews SET status = ? WHERE id = ?');
                    try {
                        $stmt->execute([$action === 'approve' ? 'approved' : 'rejected', $id]);
                        $success = 'Отзыв успешно ' . ($action === 'approve' ? 'одобрен' : 'отклонен');
                    } catch (PDOException $e) {
                        $error = 'Ошибка при модерации отзыва';
                    }
                }
                break;
        }
    }
}

// Get data for display
$services = getAllServices($pdo);
$pending_reviews = getPendingReviews($pdo);
$approved_reviews = getApprovedReviews($pdo);
?>
<!DOCTYPE html>
<html lang="ru" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - ООО «Алгоритм»</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#1a1a1a',
                        secondary: '#f5f5f5',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
    <!-- Header -->
    <header class="fixed w-full bg-white dark:bg-gray-900 shadow-sm z-50">
        <nav class="container mx-auto px-4 py-4 flex justify-between items-center">
            <a href="/" class="text-2xl font-bold">Алгоритм</a>
            <div class="flex items-center space-x-4">
                <button id="themeToggle" class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path class="dark:hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                        <path class="hidden dark:block" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/>
                    </svg>
                </button>
                <a href="/logout.php" class="px-4 py-2 rounded-lg bg-gray-900 dark:bg-white text-white dark:text-gray-900 hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">Выйти</a>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="pt-32 pb-20 px-4">
        <div class="container mx-auto">
            <h1 class="text-4xl font-bold mb-8">Панель администратора</h1>

            <?php if ($success): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <span class="block sm:inline"><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <span class="block sm:inline"><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <!-- Services Management -->
            <section class="mb-12">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold">Управление услугами</h2>
                    <button onclick="document.getElementById('addServiceModal').classList.remove('hidden')" class="px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                        Добавить услугу
                    </button>
                </div>

                <div class="grid gap-6">
                    <?php foreach ($services as $service): ?>
                        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h3 class="text-xl font-bold"><?php echo htmlspecialchars($service['title']); ?></h3>
                                    <p class="text-gray-600 dark:text-gray-400 mt-2"><?php echo htmlspecialchars($service['brief_description']); ?></p>
                                    <div class="mt-4">
                                        <p class="text-lg font-bold"><?php echo formatPrice($service['price']); ?></p>
                                        <p class="text-sm text-gray-600 dark:text-gray-400">Срок: <?php echo $service['duration_days']; ?> дней</p>
                                    </div>
                                </div>
                                <div class="flex space-x-2">
                                    <button onclick="editService(<?php echo htmlspecialchars(json_encode($service)); ?>)" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 transition-all">
                                        Редактировать
                                    </button>
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                        <input type="hidden" name="action" value="delete_service">
                                        <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
                                        <button type="submit" class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 transition-all">
                                            Удалить
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- Reviews Moderation -->
            <section>
                <h2 class="text-2xl font-bold mb-6">Модерация отзывов</h2>
                
                <!-- Pending Reviews -->
                <div class="mb-8">
                    <h3 class="text-xl font-bold mb-4">Ожидают модерации</h3>
                    <?php if (empty($pending_reviews)): ?>
                        <p class="text-gray-600 dark:text-gray-400">Нет отзывов для модерации</p>
                    <?php else: ?>
                        <div class="grid gap-6">
                            <?php foreach ($pending_reviews as $review): ?>
                                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-bold"><?php echo htmlspecialchars($review['user_email']); ?></p>
                                            <p class="text-gray-600 dark:text-gray-400">Услуга: <?php echo htmlspecialchars($review['service_title']); ?></p>
                                            <p class="mt-2"><?php echo htmlspecialchars($review['comment']); ?></p>
                                            <div class="mt-2">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <svg class="inline-block w-5 h-5 <?php echo $i <= $review['rating'] ? 'text-yellow-400' : 'text-gray-300'; ?>" fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                                    </svg>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        <form method="POST" class="flex space-x-2">
                                            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                            <input type="hidden" name="action" value="moderate_review">
                                            <input type="hidden" name="id" value="<?php echo $review['id']; ?>">
                                            <input type="hidden" name="moderation_action" value="approve">
                                            <button type="submit" class="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 transition-all">
                                                Одобрить
                                            </button>
                                            <input type="hidden" name="moderation_action" value="reject">
                                            <button type="submit" class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 transition-all">
                                                Отклонить
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Approved Reviews -->
                <div>
                    <h3 class="text-xl font-bold mb-4">Одобренные отзывы</h3>
                    <?php if (empty($approved_reviews)): ?>
                        <p class="text-gray-600 dark:text-gray-400">Нет одобренных отзывов</p>
                    <?php else: ?>
                        <div class="grid gap-6">
                            <?php foreach ($approved_reviews as $review): ?>
                                <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
                                    <div>
                                        <p class="font-bold"><?php echo htmlspecialchars($review['user_email']); ?></p>
                                        <p class="text-gray-600 dark:text-gray-400">Услуга: <?php echo htmlspecialchars($review['service_title']); ?></p>
                                        <p class="mt-2"><?php echo htmlspecialchars($review['comment']); ?></p>
                                        <div class="mt-2">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <svg class="inline-block w-5 h-5 <?php echo $i <= $review['rating'] ? 'text-yellow-400' : 'text-gray-300'; ?>" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                                                </svg>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>

    <!-- Add Service Modal -->
    <div id="addServiceModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white dark:bg-gray-900 rounded-lg p-8 max-w-2xl w-full mx-4">
            <div class="flex justify-between items-start mb-6">
                <h3 class="text-2xl font-bold">Добавить услугу</h3>
                <button onclick="document.getElementById('addServiceModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" value="add_service">
                <div class="space-y-4">
                    <div>
                        <label for="title" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Название</label>
                        <input type="text" id="title" name="title" required class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800">
                    </div>
                    <div>
                        <label for="brief_description" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Краткое описание</label>
                        <textarea id="brief_description" name="brief_description" required rows="2" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800"></textarea>
                    </div>
                    <div>
                        <label for="full_description" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Полное описание</label>
                        <textarea id="full_description" name="full_description" required rows="6" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800"></textarea>
                    </div>
                    <div>
                        <label for="price" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Стоимость</label>
                        <input type="number" id="price" name="price" required min="0" step="0.01" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800">
                    </div>
                    <div>
                        <label for="duration_days" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Срок выполнения (дней)</label>
                        <input type="number" id="duration_days" name="duration_days" required min="1" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800">
                    </div>
                </div>
                <div class="mt-6">
                    <button type="submit" class="w-full px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                        Добавить
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Service Modal -->
    <div id="editServiceModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
        <div class="bg-white dark:bg-gray-900 rounded-lg p-8 max-w-2xl w-full mx-4">
            <div class="flex justify-between items-start mb-6">
                <h3 class="text-2xl font-bold">Редактировать услугу</h3>
                <button onclick="document.getElementById('editServiceModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" value="edit_service">
                <input type="hidden" name="id" id="edit_id">
                <div class="space-y-4">
                    <div>
                        <label for="edit_title" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Название</label>
                        <input type="text" id="edit_title" name="title" required class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800">
                    </div>
                    <div>
                        <label for="edit_brief_description" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Краткое описание</label>
                        <textarea id="edit_brief_description" name="brief_description" required rows="2" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800"></textarea>
                    </div>
                    <div>
                        <label for="edit_full_description" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Полное описание</label>
                        <textarea id="edit_full_description" name="full_description" required rows="6" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800"></textarea>
                    </div>
                    <div>
                        <label for="edit_price" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Стоимость</label>
                        <input type="number" id="edit_price" name="price" required min="0" step="0.01" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800">
                    </div>
                    <div>
                        <label for="edit_duration_days" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Срок выполнения (дней)</label>
                        <input type="number" id="edit_duration_days" name="duration_days" required min="1" class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-700 shadow-sm focus:border-gray-500 focus:ring-gray-500 dark:bg-gray-800">
                    </div>
                </div>
                <div class="mt-6">
                    <button type="submit" class="w-full px-4 py-2 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-100 transition-all">
                        Сохранить
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Theme Toggle
        const themeToggle = document.getElementById('themeToggle');
        const html = document.documentElement;
        
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            html.classList.add('dark');
        } else {
            html.classList.remove('dark');
        }

        themeToggle.addEventListener('click', () => {
            html.classList.toggle('dark');
            localStorage.theme = html.classList.contains('dark') ? 'dark' : 'light';
        });

        // Edit Service
        function editService(service) {
            document.getElementById('edit_id').value = service.id;
            document.getElementById('edit_title').value = service.title;
            document.getElementById('edit_brief_description').value = service.brief_description;
            document.getElementById('edit_full_description').value = service.full_description;
            document.getElementById('edit_price').value = service.price;
            document.getElementById('edit_duration_days').value = service.duration_days;
            document.getElementById('editServiceModal').classList.remove('hidden');
        }
    </script>
</body>
</html> 