-- Добавление поля рейтинга для отзывов
ALTER TABLE reviews ADD COLUMN rating INT DEFAULT 5;

-- Обновление существующих отзывов
UPDATE reviews SET rating = 5 WHERE rating IS NULL; 